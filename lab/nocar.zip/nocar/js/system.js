$(document).ready(function(){
	$(window).scroll(function(){
		var _bannerHeight = $(".welcome-screen-banner").outerHeight();
		var _scrollTop = $(window).scrollTop();
		if(_scrollTop > _bannerHeight - 100)
		{
			$(".nocar-navbar").addClass("dark");
		}
		else if(_scrollTop <= _bannerHeight - 100)
		{
			$(".nocar-navbar").removeClass("dark");
		}
	});

	var currentTab = 1;

	$(".nocar-product-tab-link").click(function(){
		$(".nocar-product-tab-link").removeClass("active");
		$(this).addClass("active");

		var _tab = Number($(this).attr("data-nocar-product-tab"));

		if(_tab == currentTab)
		{
			return false;
		}
		else
		{
			$("[data-nocar-product-content="+currentTab+"]").removeClass("open");
			$("[data-nocar-product-content="+_tab+"]").addClass("open");

			currentTab = _tab;
		}
	});

	$(".npt-m-toggle").click(function(){
		if($(window).outerWidth() <= 767 || $(this).hasClass("always-dropdown"))
		{
			var _content = $(this).siblings(".npt-m-content");
			if(_content.length == 0)
			{
				_content = $(this).parents("h5").siblings(".npt-m-content");
			}
			_content.toggleClass("open");
			$(this).toggleClass("active");
		}
	})

	$(".nocar-brands-show-more").click(function(){
		$(this).toggleClass("active");
		$(".nocar-additional-brands").toggleClass("open");
	})

	$(".show-all-text a").click(function(){
		var _parent = $(this).parents("p.newsletter-rules")
		_parent.toggleClass("open");
	});
});





